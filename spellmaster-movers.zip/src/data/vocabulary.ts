export interface Word {
  id: string;
  word: string;
  topic: string;
  ipa?: string;
  meaning_vi?: string;
  definition?: string;
  example?: string;
}

export const MOVERS_VOCABULARY: Word[] = [
  // Family
  { id: 'f1', word: 'father', topic: 'Family', ipa: '/ˈfɑːðər/', meaning_vi: 'bố' },
  { id: 'f2', word: 'mother', topic: 'Family', ipa: '/ˈmʌðər/', meaning_vi: 'mẹ' },
  { id: 'f3', word: 'brother', topic: 'Family', ipa: '/ˈbrʌðər/', meaning_vi: 'anh/em trai' },
  { id: 'f4', word: 'sister', topic: 'Family', ipa: '/ˈsɪstər/', meaning_vi: 'chị/em gái' },
  { id: 'f5', word: 'grandmother', topic: 'Family', ipa: '/ˈɡrænmʌðər/', meaning_vi: 'bà' },
  { id: 'f6', word: 'grandfather', topic: 'Family', ipa: '/ˈɡrændfɑːðər/', meaning_vi: 'ông' },
  { id: 'f7', word: 'uncle', topic: 'Family', ipa: '/ˈʌŋkl/', meaning_vi: 'chú/bác trai' },
  { id: 'f8', word: 'aunt', topic: 'Family', ipa: '/ænt/', meaning_vi: 'cô/bác gái' },
  { id: 'f9', word: 'cousin', topic: 'Family', ipa: '/ˈkʌzn/', meaning_vi: 'anh/chị/em họ' },
  { id: 'f10', word: 'baby', topic: 'Family', ipa: '/ˈbeɪbi/', meaning_vi: 'em bé' },
  { id: 'f11', word: 'parents', topic: 'Family', ipa: '/ˈpeərənts/', meaning_vi: 'cha mẹ' },
  { id: 'f12', word: 'son', topic: 'Family', ipa: '/sʌn/', meaning_vi: 'con trai' },
  { id: 'f13', word: 'daughter', topic: 'Family', ipa: '/ˈdɔːtər/', meaning_vi: 'con gái' },
  { id: 'f14', word: 'family', topic: 'Family', ipa: '/ˈfæməli/', meaning_vi: 'gia đình' },
  { id: 'f15', word: 'husband', topic: 'Family', ipa: '/ˈhʌzbənd/', meaning_vi: 'chồng' },

  // School
  { id: 's1', word: 'school', topic: 'School', ipa: '/skuːl/', meaning_vi: 'trường học' },
  { id: 's2', word: 'teacher', topic: 'School', ipa: '/ˈtiːtʃər/', meaning_vi: 'giáo viên' },
  { id: 's3', word: 'student', topic: 'School', ipa: '/ˈstjuːdənt/', meaning_vi: 'học sinh' },
  { id: 's4', word: 'classroom', topic: 'School', ipa: '/ˈklɑːsruːm/', meaning_vi: 'lớp học' },
  { id: 's5', word: 'desk', topic: 'School', ipa: '/desk/', meaning_vi: 'bàn học' },
  { id: 's6', word: 'chair', topic: 'School', ipa: '/tʃeər/', meaning_vi: 'ghế' },
  { id: 's7', word: 'book', topic: 'School', ipa: '/bʊk/', meaning_vi: 'sách' },
  { id: 's8', word: 'pen', topic: 'School', ipa: '/pen/', meaning_vi: 'bút' },
  { id: 's9', word: 'pencil', topic: 'School', ipa: '/ˈpensl/', meaning_vi: 'bút chì' },
  { id: 's10', word: 'bag', topic: 'School', ipa: '/bæɡ/', meaning_vi: 'cặp sách' },
  { id: 's11', word: 'notebook', topic: 'School', ipa: '/ˈnəʊtbʊk/', meaning_vi: 'vở' },
  { id: 's12', word: 'ruler', topic: 'School', ipa: '/ˈruːlər/', meaning_vi: 'thước' },
  { id: 's13', word: 'eraser', topic: 'School', ipa: '/ɪˈreɪsər/', meaning_vi: 'tẩy' },
  { id: 's14', word: 'playground', topic: 'School', ipa: '/ˈpleɪɡraʊnd/', meaning_vi: 'sân chơi' },
  { id: 's15', word: 'board', topic: 'School', ipa: '/bɔːrd/', meaning_vi: 'bảng' },

  // Food and Drink
  { id: 'fd1', word: 'bread', topic: 'Food and Drink', ipa: '/bred/', meaning_vi: 'bánh mì' },
  { id: 'fd2', word: 'rice', topic: 'Food and Drink', ipa: '/raɪs/', meaning_vi: 'cơm' },
  { id: 'fd3', word: 'egg', topic: 'Food and Drink', ipa: '/eɡ/', meaning_vi: 'trứng' },
  { id: 'fd4', word: 'milk', topic: 'Food and Drink', ipa: '/mɪlk/', meaning_vi: 'sữa' },
  { id: 'fd5', word: 'water', topic: 'Food and Drink', ipa: '/ˈwɔːtər/', meaning_vi: 'nước' },
  { id: 'fd6', word: 'apple', topic: 'Food and Drink', ipa: '/ˈæpl/', meaning_vi: 'táo' },
  { id: 'fd7', word: 'banana', topic: 'Food and Drink', ipa: '/bəˈnɑːnə/', meaning_vi: 'chuối' },
  { id: 'fd8', word: 'orange', topic: 'Food and Drink', ipa: '/ˈɒrɪndʒ/', meaning_vi: 'cam' },
  { id: 'fd9', word: 'cheese', topic: 'Food and Drink', ipa: '/tʃiːz/', meaning_vi: 'pho mát' },
  { id: 'fd10', word: 'chicken', topic: 'Food and Drink', ipa: '/ˈtʃɪkɪn/', meaning_vi: 'gà' },
  { id: 'fd11', word: 'fish', topic: 'Food and Drink', ipa: '/fɪʃ/', meaning_vi: 'cá' },
  { id: 'fd12', word: 'juice', topic: 'Food and Drink', ipa: '/dʒuːs/', meaning_vi: 'nước ép' },
  { id: 'fd13', word: 'cake', topic: 'Food and Drink', ipa: '/keɪk/', meaning_vi: 'bánh ngọt' },
  { id: 'fd14', word: 'soup', topic: 'Food and Drink', ipa: '/suːp/', meaning_vi: 'súp' },
  { id: 'fd15', word: 'tomato', topic: 'Food and Drink', ipa: '/təˈmɑːtəʊ/', meaning_vi: 'cà chua' },

  // Animals
  { id: 'a1', word: 'cat', topic: 'Animals', ipa: '/kæt/', meaning_vi: 'mèo' },
  { id: 'a2', word: 'dog', topic: 'Animals', ipa: '/dɒɡ/', meaning_vi: 'chó' },
  { id: 'a3', word: 'bird', topic: 'Animals', ipa: '/bɜːrd/', meaning_vi: 'chim' },
  { id: 'a4', word: 'fish', topic: 'Animals', ipa: '/fɪʃ/', meaning_vi: 'cá' },
  { id: 'a5', word: 'rabbit', topic: 'Animals', ipa: '/ˈræbɪt/', meaning_vi: 'thỏ' },
  { id: 'a6', word: 'horse', topic: 'Animals', ipa: '/hɔːrs/', meaning_vi: 'ngựa' },
  { id: 'a7', word: 'cow', topic: 'Animals', ipa: '/kaʊ/', meaning_vi: 'bò' },
  { id: 'a8', word: 'sheep', topic: 'Animals', ipa: '/ʃiːp/', meaning_vi: 'cừu' },
  { id: 'a9', word: 'pig', topic: 'Animals', ipa: '/pɪɡ/', meaning_vi: 'lợn' },
  { id: 'a10', word: 'duck', topic: 'Animals', ipa: '/dʌk/', meaning_vi: 'vịt' },
  { id: 'a11', word: 'elephant', topic: 'Animals', ipa: '/ˈelɪfənt/', meaning_vi: 'voi' },
  { id: 'a12', word: 'tiger', topic: 'Animals', ipa: '/ˈtaɪɡər/', meaning_vi: 'hổ' },
  { id: 'a13', word: 'lion', topic: 'Animals', ipa: '/ˈlaɪən/', meaning_vi: 'sư tử' },
  { id: 'a14', word: 'monkey', topic: 'Animals', ipa: '/ˈmʌŋki/', meaning_vi: 'khỉ' },
  { id: 'a15', word: 'bear', topic: 'Animals', ipa: '/beər/', meaning_vi: 'gấu' }
];

export const TOPICS = Array.from(new Set(MOVERS_VOCABULARY.map(v => v.topic)));
