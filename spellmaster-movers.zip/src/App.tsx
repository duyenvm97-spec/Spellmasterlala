import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Home as HomeIcon, BookOpen, Mic, Trophy, Settings, ArrowLeft, Volume2, CheckCircle2, XCircle, Star, Play, RotateCcw, BarChart3 } from 'lucide-react';
import confetti from 'canvas-confetti';
import Markdown from 'react-markdown';

import { MOVERS_VOCABULARY, TOPICS, Word } from './data/vocabulary';
import { generatePronunciation, analyzePronunciation, checkSpelling, playPcm } from './services/gemini';
import { useRecorder } from './hooks/useRecorder';

// --- Types ---
type Screen = 'HOME' | 'PRACTICE' | 'PRONUNCIATION' | 'QUIZ' | 'PROGRESS';

interface ProgressData {
  learnedWords: string[];
  misspelledWords: Record<string, number>;
  pronunciationScores: Record<string, number>;
}

// --- Main App Component ---
export default function App() {
  const [screen, setScreen] = useState<Screen>('HOME');
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [progress, setProgress] = useState<ProgressData>(() => {
    const saved = localStorage.getItem('spellmaster_progress');
    return saved ? JSON.parse(saved) : { learnedWords: [], misspelledWords: {}, pronunciationScores: {} };
  });

  useEffect(() => {
    localStorage.setItem('spellmaster_progress', JSON.stringify(progress));
  }, [progress]);

  const updateProgress = (word: string, type: 'learned' | 'misspelled' | 'pronunciation', score?: number) => {
    setProgress(prev => {
      const next = { ...prev };
      if (type === 'learned' && !next.learnedWords.includes(word)) {
        next.learnedWords.push(word);
      } else if (type === 'misspelled') {
        next.misspelledWords[word] = (next.misspelledWords[word] || 0) + 1;
      } else if (type === 'pronunciation' && score !== undefined) {
        next.pronunciationScores[word] = Math.max(next.pronunciationScores[word] || 0, score);
      }
      return next;
    });
  };

  const renderScreen = () => {
    switch (screen) {
      case 'HOME':
        return <HomeScreen onSelectTopic={(topic) => { setSelectedTopic(topic); setScreen('PRACTICE'); }} onGoToProgress={() => setScreen('PROGRESS')} />;
      case 'PRACTICE':
        return <PracticeScreen topic={selectedTopic!} onBack={() => setScreen('HOME')} onComplete={() => setScreen('PRONUNCIATION')} updateProgress={updateProgress} />;
      case 'PRONUNCIATION':
        return <PronunciationScreen topic={selectedTopic!} onBack={() => setScreen('HOME')} onComplete={() => setScreen('QUIZ')} updateProgress={updateProgress} />;
      case 'QUIZ':
        return <QuizScreen topic={selectedTopic!} onBack={() => setScreen('HOME')} onComplete={() => { confetti(); setScreen('PROGRESS'); }} updateProgress={updateProgress} />;
      case 'PROGRESS':
        return <ProgressScreen progress={progress} onBack={() => setScreen('HOME')} />;
      default:
        return <HomeScreen onSelectTopic={(topic) => { setSelectedTopic(topic); setScreen('PRACTICE'); }} onGoToProgress={() => setScreen('PROGRESS')} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center p-4 md:p-8">
      <header className="w-full max-w-4xl flex justify-between items-center mb-8">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setScreen('HOME')}>
          <div className="bg-red-500 p-2 rounded-xl shadow-lg">
            <BookOpen className="text-white w-8 h-8" />
          </div>
          <h1 className="text-3xl font-black text-red-600 tracking-tight font-display">SpellMaster</h1>
        </div>
        <div className="flex gap-4">
          <button onClick={() => setScreen('PROGRESS')} className="p-3 bg-white rounded-xl shadow-md hover:bg-red-50 transition-colors">
            <BarChart3 className="text-red-500 w-6 h-6" />
          </button>
        </div>
      </header>

      <main className="w-full max-w-4xl flex-1 flex flex-col">
        <AnimatePresence mode="wait">
          <motion.div
            key={screen + (selectedTopic || '')}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="flex-1 flex flex-col"
          >
            {renderScreen()}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}

// --- Screen Components ---

function HomeScreen({ onSelectTopic, onGoToProgress }: { onSelectTopic: (topic: string) => void, onGoToProgress: () => void }) {
  return (
    <div className="flex flex-col items-center text-center">
      <motion.div 
        initial={{ scale: 0.8 }}
        animate={{ scale: 1 }}
        className="mb-8"
      >
        <img src="https://picsum.photos/seed/learning/400/300" alt="Learning" className="rounded-3xl shadow-2xl border-8 border-white mb-6" referrerPolicy="no-referrer" />
        <h2 className="text-4xl font-black text-gray-800 mb-2 font-display">Ready to Learn?</h2>
        <p className="text-xl text-gray-600">Choose a topic to start your adventure!</p>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full">
        {TOPICS.map((topic) => (
          <motion.div
            key={topic}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onSelectTopic(topic)}
            className="topic-card"
          >
            <div className="bg-red-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Star className="text-red-500 fill-red-500" />
            </div>
            <span className="text-lg font-bold text-gray-700">{topic}</span>
          </motion.div>
        ))}
      </div>
      
      <button onClick={onGoToProgress} className="mt-12 btn-secondary flex items-center gap-2">
        <Trophy className="w-6 h-6" />
        View My Progress
      </button>
    </div>
  );
}

function PracticeScreen({ topic, onBack, onComplete, updateProgress }: { topic: string, onBack: () => void, onComplete: () => void, updateProgress: (word: string, type: 'learned' | 'misspelled' | 'pronunciation', score?: number) => void }) {
  const words = MOVERS_VOCABULARY.filter(v => v.topic === topic);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [input, setInput] = useState('');
  const [feedback, setFeedback] = useState<{ isCorrect: boolean, suggestions: string, explanation: string } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [pronunciationResult, setPronunciationResult] = useState<{ score: number, feedback: string, recognizedText: string } | null>(null);
  const currentWord = words[currentIndex];
  const { isRecording, audioBase64, mimeType, startRecording, stopRecording, clearAudio } = useRecorder();

  const handlePlayAudio = async () => {
    setIsGeneratingAudio(true);
    const base64 = await generatePronunciation(currentWord.word);
    setIsGeneratingAudio(false);
    if (base64) {
      await playPcm(base64);
    }
  };

  const handleSubmit = async () => {
    if (!input.trim()) return;
    setIsLoading(true);
    const result = await checkSpelling(currentWord.word, input);
    setFeedback(result);
    setIsLoading(false);

    if (result.isCorrect) {
      updateProgress(currentWord.word, 'learned');
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    } else {
      updateProgress(currentWord.word, 'misspelled');
    }
  };

  useEffect(() => {
    if (audioBase64) {
      handleAnalyze();
    }
  }, [audioBase64]);

  const handleAnalyze = async () => {
    if (!audioBase64) return;
    setIsAnalyzing(true);
    const analysis = await analyzePronunciation(currentWord.word, audioBase64, mimeType);
    setPronunciationResult(analysis);
    setIsAnalyzing(false);
    updateProgress(currentWord.word, 'pronunciation', analysis.score);
    if (analysis.score > 80) {
      confetti({ particleCount: 30, spread: 50 });
    }
  };

  const nextWord = () => {
    if (currentIndex < words.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setInput('');
      setFeedback(null);
      setPronunciationResult(null);
      clearAudio();
    } else {
      onComplete();
    }
  };

  return (
    <div className="card flex flex-col items-center">
      <div className="w-full flex justify-between items-center mb-8">
        <button onClick={onBack} className="text-gray-400 hover:text-red-500 transition-colors">
          <ArrowLeft className="w-8 h-8" />
        </button>
        <div className="text-lg font-bold text-red-500 bg-red-50 px-4 py-1 rounded-full">
          Practice: {topic} ({currentIndex + 1}/{words.length})
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full">
        {/* Left Side: Listening & Writing */}
        <div className="flex flex-col items-center space-y-6">
          <div className="text-center">
            <button 
              onClick={handlePlayAudio} 
              disabled={isGeneratingAudio}
              className={`w-20 h-20 bg-red-500 rounded-full flex items-center justify-center shadow-lg hover:bg-red-600 transition-all transform hover:scale-110 mb-4 mx-auto ${isGeneratingAudio ? 'animate-pulse opacity-70' : ''}`}
            >
              <Volume2 className="text-white w-10 h-10" />
            </button>
            <p className="text-gray-500 font-medium">{isGeneratingAudio ? 'Generating...' : 'Listen and type!'}</p>
            {currentWord.meaning_vi && (
              <div className="mt-2 inline-block bg-red-100 text-red-700 px-3 py-1 rounded-lg text-sm font-bold">
                Hint: {currentWord.meaning_vi}
              </div>
            )}
          </div>

          <div className="w-full space-y-4">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type the word..."
              className="input-field"
              autoFocus
              onKeyDown={(e) => e.key === 'Enter' && !feedback && handleSubmit()}
            />

            {!feedback ? (
              <button onClick={handleSubmit} disabled={isLoading} className="w-full btn-primary">
                {isLoading ? 'Checking...' : 'Check Spelling'}
              </button>
            ) : (
              <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className={`p-4 rounded-xl ${feedback.isCorrect ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
                <div className="flex items-center gap-2 mb-2">
                  {feedback.isCorrect ? <CheckCircle2 className="text-green-500 w-6 h-6" /> : <XCircle className="text-red-500 w-6 h-6" />}
                  <h3 className={`text-lg font-bold ${feedback.isCorrect ? 'text-green-700' : 'text-red-700'}`}>
                    {feedback.isCorrect ? 'Correct!' : 'Try again!'}
                  </h3>
                </div>
                <div className="text-sm text-gray-700">
                  <Markdown>{feedback.explanation}</Markdown>
                </div>
              </motion.div>
            )}
          </div>
        </div>

        {/* Right Side: Pronunciation */}
        <div className="flex flex-col items-center justify-center border-l-2 border-red-50 pl-8">
          <h3 className="text-xl font-bold text-gray-700 mb-4">Practice Speaking</h3>
          
          {!pronunciationResult ? (
            <div className="flex flex-col items-center gap-4">
              <button
                onMouseDown={startRecording}
                onMouseUp={stopRecording}
                onTouchStart={startRecording}
                onTouchEnd={stopRecording}
                className={`w-24 h-24 rounded-full flex items-center justify-center shadow-xl transition-all transform active:scale-90 ${isRecording ? 'bg-red-600 animate-pulse' : 'bg-red-500 hover:bg-red-600'}`}
              >
                <Mic className="text-white w-12 h-12" />
              </button>
              <p className="font-bold text-gray-500">
                {isRecording ? 'Listening...' : 'Hold to Speak!'}
              </p>
              {isAnalyzing && <p className="text-red-500 animate-bounce text-sm font-bold">AI is checking...</p>}
            </div>
          ) : (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="w-full bg-red-50 rounded-2xl p-6 text-center">
              <div className="text-4xl font-black text-red-500 mb-1">{pronunciationResult.score}</div>
              <div className="text-xs font-bold text-gray-400 uppercase mb-4">Score</div>
              <p className="text-sm text-gray-700 mb-4 italic">"{pronunciationResult.recognizedText}"</p>
              <button onClick={() => { setPronunciationResult(null); clearAudio(); }} className="text-red-500 font-bold flex items-center gap-1 mx-auto hover:underline">
                <RotateCcw className="w-4 h-4" /> Try Again
              </button>
            </motion.div>
          )}
        </div>
      </div>

      <button 
        onClick={nextWord} 
        disabled={!feedback && !pronunciationResult}
        className={`mt-10 w-full max-w-md btn-primary ${(!feedback && !pronunciationResult) ? 'opacity-50 cursor-not-allowed' : 'bg-gray-800 hover:bg-gray-900'}`}
      >
        {currentIndex < words.length - 1 ? 'Next Word' : 'Finish Practice'}
      </button>
    </div>
  );
}

function PronunciationScreen({ topic, onBack, onComplete, updateProgress }: { topic: string, onBack: () => void, onComplete: () => void, updateProgress: (word: string, type: 'learned' | 'misspelled' | 'pronunciation', score?: number) => void }) {
  const words = MOVERS_VOCABULARY.filter(v => v.topic === topic);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const [result, setResult] = useState<{ score: number, feedback: string, recognizedText: string } | null>(null);
  const currentWord = words[currentIndex];
  const { isRecording, audioBase64, mimeType, startRecording, stopRecording, clearAudio } = useRecorder();

  const handlePlayAudio = async () => {
    setIsGeneratingAudio(true);
    const base64 = await generatePronunciation(currentWord.word);
    setIsGeneratingAudio(false);
    if (base64) {
      await playPcm(base64);
    }
  };

  useEffect(() => {
    if (audioBase64) {
      handleAnalyze();
    }
  }, [audioBase64]);

  const handleAnalyze = async () => {
    if (!audioBase64) return;
    setIsAnalyzing(true);
    const analysis = await analyzePronunciation(currentWord.word, audioBase64, mimeType);
    setResult(analysis);
    setIsAnalyzing(false);
    updateProgress(currentWord.word, 'pronunciation', analysis.score);
    if (analysis.score > 80) {
      confetti({ particleCount: 30, spread: 50 });
    }
  };

  const nextWord = () => {
    if (currentIndex < words.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setResult(null);
      clearAudio();
    } else {
      onComplete();
    }
  };

  return (
    <div className="card flex flex-col items-center">
      <div className="w-full flex justify-between items-center mb-8">
        <button onClick={onBack} className="text-gray-400 hover:text-red-500 transition-colors">
          <ArrowLeft className="w-8 h-8" />
        </button>
        <div className="text-lg font-bold text-red-500 bg-red-50 px-4 py-1 rounded-full">
          Pronunciation: {topic} ({currentIndex + 1}/{words.length})
        </div>
      </div>

      <div className="mb-12 text-center">
        <h2 className="text-5xl font-black text-gray-800 mb-2 font-display uppercase tracking-tight">{currentWord.word}</h2>
        {currentWord.ipa && <p className="text-2xl text-red-400 font-mono mb-4">{currentWord.ipa}</p>}
        {currentWord.meaning_vi && <p className="text-xl text-gray-500 mb-6 font-bold">({currentWord.meaning_vi})</p>}
        <button 
          onClick={handlePlayAudio} 
          disabled={isGeneratingAudio}
          className={`flex items-center gap-2 mx-auto bg-red-100 text-red-600 px-6 py-3 rounded-2xl font-bold hover:bg-red-200 transition-colors mb-8 ${isGeneratingAudio ? 'animate-pulse' : ''}`}
        >
          <Volume2 className="w-6 h-6" />
          {isGeneratingAudio ? 'Generating...' : 'Listen to Correct Pronunciation'}
        </button>
      </div>

      <div className="w-full max-w-md flex flex-col items-center gap-8">
        {!result ? (
          <div className="flex flex-col items-center gap-4">
            <button
              onMouseDown={startRecording}
              onMouseUp={stopRecording}
              onTouchStart={startRecording}
              onTouchEnd={stopRecording}
              className={`w-32 h-32 rounded-full flex items-center justify-center shadow-2xl transition-all transform active:scale-90 ${isRecording ? 'bg-red-600 animate-pulse' : 'bg-red-500 hover:bg-red-600'}`}
            >
              <Mic className="text-white w-16 h-16" />
            </button>
            <p className="text-xl font-bold text-gray-600">
              {isRecording ? 'Listening...' : 'Hold to Speak!'}
            </p>
            {isAnalyzing && <p className="text-red-500 animate-bounce font-bold">AI is checking your voice...</p>}
          </div>
        ) : (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full bg-white rounded-3xl border-4 border-red-100 p-8 shadow-lg text-center">
            <div className="text-6xl font-black text-red-500 mb-2">{result.score}</div>
            <div className="text-xl font-bold text-gray-400 uppercase tracking-widest mb-6">Score</div>
            
            <div className="bg-red-50 p-6 rounded-2xl text-left mb-8">
              <p className="text-gray-700 text-lg leading-relaxed">{result.feedback}</p>
              <div className="mt-4 pt-4 border-t border-red-200">
                <p className="text-sm text-gray-400 uppercase font-bold">You said:</p>
                <p className="text-xl font-bold text-red-400 italic">"{result.recognizedText}"</p>
              </div>
            </div>

            <div className="flex gap-4">
              <button onClick={() => { setResult(null); clearAudio(); }} className="flex-1 btn-secondary py-3 text-lg flex items-center justify-center gap-2">
                <RotateCcw className="w-5 h-5" /> Try Again
              </button>
              <button onClick={nextWord} className="flex-1 btn-primary py-3 text-lg">
                Next Word
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

function QuizScreen({ topic, onBack, onComplete, updateProgress }: { topic: string, onBack: () => void, onComplete: () => void, updateProgress: (word: string, type: 'learned' | 'misspelled' | 'pronunciation') => void }) {
  const words = MOVERS_VOCABULARY.filter(v => v.topic === topic);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [options, setOptions] = useState<string[]>([]);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const currentWord = words[currentIndex];

  useEffect(() => {
    // Generate 3 wrong options
    const otherWords = MOVERS_VOCABULARY.filter(v => v.word !== currentWord.word).map(v => v.word);
    const shuffled = [...otherWords].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, 3);
    setOptions([...selected, currentWord.word].sort(() => 0.5 - Math.random()));
    setSelectedOption(null);
    setIsCorrect(null);
  }, [currentIndex, currentWord]);

  const handlePlayAudio = async () => {
    setIsGeneratingAudio(true);
    const base64 = await generatePronunciation(currentWord.word);
    setIsGeneratingAudio(false);
    if (base64) {
      await playPcm(base64);
    }
  };

  const handleSelect = (option: string) => {
    if (selectedOption) return;
    setSelectedOption(option);
    const correct = option === currentWord.word;
    setIsCorrect(correct);
    if (correct) {
      confetti({ particleCount: 40, spread: 70 });
      updateProgress(currentWord.word, 'learned');
    } else {
      updateProgress(currentWord.word, 'misspelled');
    }
  };

  const nextQuestion = () => {
    if (currentIndex < words.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="card flex flex-col items-center">
      <div className="w-full flex justify-between items-center mb-8">
        <button onClick={onBack} className="text-gray-400 hover:text-red-500 transition-colors">
          <ArrowLeft className="w-8 h-8" />
        </button>
        <div className="text-lg font-bold text-red-500 bg-red-50 px-4 py-1 rounded-full">
          Listening Quiz: {topic} ({currentIndex + 1}/{words.length})
        </div>
      </div>

      <div className="mb-12 text-center">
        <button 
          onClick={handlePlayAudio} 
          disabled={isGeneratingAudio}
          className={`w-32 h-32 bg-red-500 rounded-full flex items-center justify-center shadow-lg hover:bg-red-600 transition-all transform hover:scale-110 mb-6 mx-auto ${isGeneratingAudio ? 'animate-pulse opacity-70' : ''}`}
        >
          <Volume2 className="text-white w-16 h-16" />
        </button>
        <h2 className="text-3xl font-black text-gray-800 font-display">{isGeneratingAudio ? 'Generating voice...' : 'Which word did you hear?'}</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-2xl">
        {options.map((option) => (
          <button
            key={option}
            onClick={() => handleSelect(option)}
            disabled={selectedOption !== null}
            className={`p-6 rounded-2xl text-2xl font-bold transition-all transform ${
              selectedOption === option
                ? isCorrect ? 'bg-green-500 text-white scale-105' : 'bg-red-500 text-white scale-105'
                : selectedOption !== null && option === currentWord.word
                  ? 'bg-green-500 text-white'
                  : 'bg-white border-4 border-red-100 text-gray-700 hover:border-red-500'
            }`}
          >
            {option}
          </button>
        ))}
      </div>

      {selectedOption && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mt-12 w-full text-center">
          <p className={`text-2xl font-bold mb-6 ${isCorrect ? 'text-green-600' : 'text-red-600'}`}>
            {isCorrect ? 'Correct! Well done!' : `Oops! The correct word was "${currentWord.word}".`}
          </p>
          <button onClick={nextQuestion} className="btn-primary px-12">
            {currentIndex < words.length - 1 ? 'Next Question' : 'Finish Quiz'}
          </button>
        </motion.div>
      )}
    </div>
  );
}

function ProgressScreen({ progress, onBack }: { progress: ProgressData, onBack: () => void }) {
  const totalWords = MOVERS_VOCABULARY.length;
  const learnedCount = progress.learnedWords.length;
  const avgPronunciation = Object.values(progress.pronunciationScores).length > 0 
    ? Math.round(Object.values(progress.pronunciationScores).reduce((a, b) => a + b, 0) / Object.values(progress.pronunciationScores).length)
    : 0;

  return (
    <div className="flex flex-col gap-8">
      <div className="flex items-center gap-4">
        <button onClick={onBack} className="text-gray-400 hover:text-red-500 transition-colors">
          <ArrowLeft className="w-8 h-8" />
        </button>
        <h2 className="text-4xl font-black text-gray-800 font-display">My Progress</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card text-center">
          <div className="text-5xl font-black text-red-500 mb-2">{learnedCount}/{totalWords}</div>
          <div className="text-lg font-bold text-gray-400 uppercase">Words Learned</div>
          <div className="mt-4 w-full bg-gray-100 h-4 rounded-full overflow-hidden">
            <div className="bg-red-500 h-full transition-all duration-1000" style={{ width: `${(learnedCount / totalWords) * 100}%` }}></div>
          </div>
        </div>
        <div className="card text-center">
          <div className="text-5xl font-black text-orange-500 mb-2">{avgPronunciation}%</div>
          <div className="text-lg font-bold text-gray-400 uppercase">Avg Pronunciation</div>
        </div>
        <div className="card text-center">
          <div className="text-5xl font-black text-blue-500 mb-2">{Object.keys(progress.misspelledWords).length}</div>
          <div className="text-lg font-bold text-gray-400 uppercase">Tricky Words</div>
        </div>
      </div>

      <div className="card">
        <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <Star className="text-yellow-500 fill-yellow-500" />
          Learned Vocabulary
        </h3>
        <div className="flex flex-wrap gap-3">
          {MOVERS_VOCABULARY.map(word => (
            <div 
              key={word.id} 
              className={`px-4 py-2 rounded-xl font-bold border-2 transition-all ${
                progress.learnedWords.includes(word.word) 
                  ? 'bg-green-50 border-green-200 text-green-700' 
                  : 'bg-gray-50 border-gray-100 text-gray-300'
              }`}
            >
              {word.word}
            </div>
          ))}
        </div>
      </div>

      {Object.keys(progress.misspelledWords).length > 0 && (
        <div className="card border-red-200">
          <h3 className="text-2xl font-bold mb-6 text-red-600 flex items-center gap-2">
            <RotateCcw className="w-6 h-6" />
            Words to Practice More
          </h3>
          <div className="space-y-4">
            {Object.entries(progress.misspelledWords)
              .sort((a, b) => b[1] - a[1])
              .map(([word, count]) => (
                <div key={word} className="flex justify-between items-center p-4 bg-red-50 rounded-2xl border border-red-100">
                  <span className="text-xl font-bold text-red-700">{word}</span>
                  <span className="bg-red-200 text-red-700 px-3 py-1 rounded-full text-sm font-black">
                    Missed {count} times
                  </span>
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}
