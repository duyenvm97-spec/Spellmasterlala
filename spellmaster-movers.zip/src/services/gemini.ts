import { GoogleGenAI, Modality, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function generatePronunciation(text: string): Promise<string | null> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: `Say clearly: ${text}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    return base64Audio || null;
  } catch (error) {
    console.error("Error generating pronunciation:", error);
    return null;
  }
}

export async function playPcm(base64: string, sampleRate: number = 24000) {
  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  const arrayBuffer = Uint8Array.from(atob(base64), c => c.charCodeAt(0)).buffer;
  
  // PCM is 16-bit little endian
  const int16Array = new Int16Array(arrayBuffer);
  const float32Array = new Float32Array(int16Array.length);
  for (let i = 0; i < int16Array.length; i++) {
    float32Array[i] = int16Array[i] / 32768;
  }

  const audioBuffer = audioContext.createBuffer(1, float32Array.length, sampleRate);
  audioBuffer.getChannelData(0).set(float32Array);

  const source = audioContext.createBufferSource();
  source.buffer = audioBuffer;
  source.connect(audioContext.destination);
  source.start();
}

export async function analyzePronunciation(targetWord: string, audioBase64: string, mimeType: string): Promise<{
  score: number;
  feedback: string;
  recognizedText: string;
}> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          parts: [
            { text: `Analyze the pronunciation of the word "${targetWord}". Compare it with the provided audio. Provide a score out of 100, feedback for a 7-10 year old student, and the text you recognized from the audio.` },
            { inlineData: { data: audioBase64, mimeType } }
          ]
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            feedback: { type: Type.STRING },
            recognizedText: { type: Type.STRING }
          },
          required: ["score", "feedback", "recognizedText"]
        }
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Error analyzing pronunciation:", error);
    return { score: 0, feedback: "Sorry, I couldn't hear you clearly. Try again!", recognizedText: "" };
  }
}

export async function checkSpelling(word: string, userInput: string): Promise<{
  isCorrect: boolean;
  suggestions: string;
  explanation: string;
}> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `The target word is "${word}". The student typed "${userInput}". Check if it's correct. If not, provide friendly suggestions and a simple explanation for a 7-10 year old.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isCorrect: { type: Type.BOOLEAN },
            suggestions: { type: Type.STRING },
            explanation: { type: Type.STRING }
          },
          required: ["isCorrect", "suggestions", "explanation"]
        }
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Error checking spelling:", error);
    return { isCorrect: word.toLowerCase() === userInput.toLowerCase(), suggestions: "", explanation: "" };
  }
}
